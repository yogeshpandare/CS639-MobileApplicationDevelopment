package com.example.yogesh.asynctaskdemo;

import android.graphics.Bitmap;
import android.os.AsyncTask;

/**
 * Created by yogesh on 10/29/2014.
 */
public class AsyncTaskTest extends AsyncTask<String,Integer,Bitmap> {
    @Override
    protected Bitmap doInBackground(String... urls) {
        return null;
    }

    @Override
    protected void onPostExecute(Bitmap img) {
        super.onPostExecute(img);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }
}
